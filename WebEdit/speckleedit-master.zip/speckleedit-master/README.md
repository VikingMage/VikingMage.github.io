# speckleedit

SpeckleEdit is an online editor for text files on drive. It's hosted on github pages: https://satelliteray.github.io/speckleedit/.

SpeckleEdit is an installable PWA app. It doesn't work offline because the backend integration required online usage, but it does cache assets for performance.

Browse the source code for examples on using the Drive V3 API to list, get and save text files.
